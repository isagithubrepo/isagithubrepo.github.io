#include <iostream>  
using namespace std;  
int main()  
{  
	int num1, num2, i;
    cout << "Hello, welcome to super basic addition calculator!" << endl;  
    cout << "Enter first number : "; 
	cin >> num1;
    cout << "Enter second number : "; 
	cin >> num2;
	
    cout << "the answer is : " << num1+num2 << endl;
	cout << "program end";
}  
