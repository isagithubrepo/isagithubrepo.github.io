I include 2 files
sbac.exe is the software
main.cpp is the sourcecode