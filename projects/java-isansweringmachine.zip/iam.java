import java.util.Scanner;

/*todo
*check for uppercase and lowercase
*proper exit
*better ai
*/
public class iam
{
	private String[] ans={
				"Yes", //do you
				"No", //do you
				"The name is Muhd Isa",
				"male", 
				"Diploma in Computer Science", 
				"Kolej Universiti Islam Selangor", //5
				"Blue and Rainbow",
				"I was born in Malaysia",
				"I am still young",
				"I am around 20 years old", 
				"I currently staying in Putrajaya Malaysia", //10 
				"I am here, in your RAM. Just kidding, I don't know where Isa currently is", 
				"I don't know", 
				"",
				"It is personal", 
				"I don't know. please ask another question" //15
				};
	
	private String[] check={"where","when","why","what","who","how", "do you"};
	
	public boolean checkProcess(String w)
	{
		int n=0;
		while (n < 7)
		{
			if(w.matches(check[n]+".*"))
				return true;
			
			n=n+1;
		}
		return false;
	}
	
	void answer(String uin)
	{
		if (checkProcess(uin)==true)
		{
			System.out.print("Answer: ");
			
			if (uin.matches(".*name.*"))	{ System.out.println(ans[2]); } 
			else if (uin.matches("how old.*"))	{ System.out.println(ans[8]); } 
			else if (uin.matches(".*age.*"))	{ System.out.println(ans[9]); } 
			else if (uin.matches(".*cert.*"))	{ System.out.println(ans[4]); }
			else if (uin.matches(".*sex.*") || uin.matches(".*gender.*"))	{ System.out.println(ans[3]); }
			else if (uin.matches(".*grad.*") || uin.matches(".*cert.*"))	{ System.out.println(ans[5]); }
			else if (uin.matches(".*where.*") && (uin.matches(".*home.*") || uin.matches(".*stay.*")))	{ System.out.println(ans[10]); }
			else if (uin.matches(".*color.*") || uin.matches(".*colour.*"))	{ System.out.println(ans[6]); } 
			else if (uin.matches("where are you.*") || uin.matches(".*your current location.*")) 	{ System.out.println(ans[11]); }
			else if (uin.matches("where.*")  || uin.matches(".*isa.*"))	{ System.out.println(ans[12]); }
			else if (uin.matches("do you.*"))	{ System.out.println(ans[0]); }	
			else { System.out.println(ans[15]); }
			System.out.print("\n");
		} else {
			System.out.println("Please ask proper question");
			System.out.print("\n");
		}
		
	}
	
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		iam t1 = new iam();
		
		String uin;
		boolean keepAsk=true;
		
		System.out.println("Hello, welcome to IAM(Isa Answering Machine) v0.01b made by isa.\nPress ctrl+c to exit\n");
		
		while (keepAsk==true)
		{
			System.out.print("Your question: ");
			uin = input.nextLine();
		
			t1.answer(uin);
		}
	}
}