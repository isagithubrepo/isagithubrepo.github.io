how to run this program?
1-extract this file
2-open cmd in this folder
3-type : java iam